class RouteStep {
  const RouteStep({
    required this.instruction,
    required this.distanceMeters,
    required this.durationSeconds,
    required this.longitude,
    required this.latitude,
    required this.type,
    this.modifier = '',
    this.name = '',
  });

  final String instruction;
  final double distanceMeters;
  final double durationSeconds;
  final double longitude;
  final double latitude;
  final String type;
  final String modifier;
  final String name;

  Map<String, dynamic> toJson() => {'instruction':instruction,'distanceMeters':distanceMeters,'durationSeconds':durationSeconds,'longitude':longitude,'latitude':latitude,'type':type,'modifier':modifier,'name':name};

  factory RouteStep.fromJson(Map<String,dynamic> json) => RouteStep(instruction:(json['instruction']??'تابع السير').toString(),distanceMeters:(json['distanceMeters'] as num? ?? 0).toDouble(),durationSeconds:(json['durationSeconds'] as num? ?? 0).toDouble(),longitude:(json['longitude'] as num? ?? 0).toDouble(),latitude:(json['latitude'] as num? ?? 0).toDouble(),type:(json['type']??'').toString(),modifier:(json['modifier']??'').toString(),name:(json['name']??'').toString());

  String get maneuverLabel {
    final m = modifier.toLowerCase();
    if (type == 'arrive') return 'وصلت إلى وجهتك';
    if (type == 'depart') return 'ابدأ السير';
    if (type == 'roundabout' || type == 'rotary') return 'ادخل الدوار';
    if (m.contains('uturn')) return 'استدر للخلف';
    if (m.contains('sharp left')) return 'انعطف يسارًا بشدة';
    if (m.contains('sharp right')) return 'انعطف يمينًا بشدة';
    if (m.contains('slight left')) return 'ميل يسارًا';
    if (m.contains('slight right')) return 'ميل يمينًا';
    if (m.contains('left')) return 'انعطف يسارًا';
    if (m.contains('right')) return 'انعطف يمينًا';
    if (type == 'merge') return 'اندماج مع الطريق';
    if (type == 'fork') return 'خذ تفرع الطريق';
    if (type == 'continue' || type == 'new name') return 'تابع السير';
    return instruction.isNotEmpty ? instruction : 'تابع السير';
  }
}

class RouteOption {
  const RouteOption({
    required this.geometry,
    required this.distanceMeters,
    required this.durationSeconds,
    required this.index,
    this.steps = const [],
    this.trafficPenaltySeconds = 0,
    this.hasLiveTraffic = false,
  });

  final List<List<double>> geometry; // [longitude, latitude]
  final double distanceMeters;
  final double durationSeconds;
  final int index;
  final List<RouteStep> steps;
  final double trafficPenaltySeconds;
  final bool hasLiveTraffic;

  Map<String, dynamic> toJson() => {'geometry':geometry,'distanceMeters':distanceMeters,'durationSeconds':durationSeconds,'index':index,'steps':steps.map((e)=>e.toJson()).toList(),'trafficPenaltySeconds':trafficPenaltySeconds,'hasLiveTraffic':hasLiveTraffic};

  factory RouteOption.fromJson(Map<String,dynamic> json) => RouteOption(geometry:((json['geometry'] as List? ?? const []).whereType<List>().where((p)=>p.length>=2).map<List<double>>((p)=>[(p[0] as num).toDouble(),(p[1] as num).toDouble()]).toList()),distanceMeters:(json['distanceMeters'] as num? ?? 0).toDouble(),durationSeconds:(json['durationSeconds'] as num? ?? 0).toDouble(),index:(json['index'] as num? ?? 0).toInt(),steps:((json['steps'] as List? ?? const []).whereType<Map>().map((e)=>RouteStep.fromJson(Map<String,dynamic>.from(e))).toList()),trafficPenaltySeconds:(json['trafficPenaltySeconds'] as num? ?? 0).toDouble(),hasLiveTraffic:json['hasLiveTraffic']==true);

  String get distanceLabel => distanceMeters >= 1000
      ? '${(distanceMeters / 1000).toStringAsFixed(1)} كم'
      : '${distanceMeters.round()} م';

  String get durationLabel {
    final m = (durationSeconds / 60).round();
    return m >= 60 ? '${m ~/ 60} س ${m % 60} د' : '$m د';
  }
}
