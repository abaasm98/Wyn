#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter SDK is required. Install Flutter and Android Studio, then run this script again."
  exit 1
fi
if [[ -z "${MAPBOX_ACCESS_TOKEN:-}" ]]; then
  echo "Set MAPBOX_ACCESS_TOKEN to your public Mapbox token before building."
  exit 1
fi
if [[ -z "${WYN_API_BASE_URL:-}" ]]; then
  echo "Set WYN_API_BASE_URL to the deployed WYN API base URL (e.g. https://example.com/api)."
  exit 1
fi
# Generate the standard Android/Gradle wrapper files with the installed Flutter SDK.
if [[ ! -d android || ! -f android/gradlew ]]; then
  tmp="$(mktemp -d)"
  cp -a lib "$tmp/lib"
  cp pubspec.yaml "$tmp/pubspec.yaml"
  cp -a assets "$tmp/assets" 2>/dev/null || true
  flutter create --platforms=android --org com.wyn --project-name app .
  rm -rf lib
  cp -a "$tmp/lib" lib
  cp "$tmp/pubspec.yaml" pubspec.yaml
  if [[ -d "$tmp/assets" ]]; then rm -rf assets; cp -a "$tmp/assets" assets; fi
  rm -rf "$tmp"
fi
mkdir -p android/app/src/main/res
cp -a android_res_icons/. android/app/src/main/res/
rm -rf android/app/src/main/res/mipmap-anydpi-v26
cp android_manifest_template.xml android/app/src/main/AndroidManifest.xml
flutter pub get
flutter build apk --release \
  --dart-define="MAPBOX_ACCESS_TOKEN=${MAPBOX_ACCESS_TOKEN}" \
  --dart-define="WYN_API_BASE_URL=${WYN_API_BASE_URL}"
mkdir -p output
cp build/app/outputs/flutter-apk/app-release.apk output/WYN-Nav-Street.apk
echo "APK created at: $(pwd)/output/WYN-Nav-Street.apk"
