import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

/// Client for the existing WYN PHP API. It persists only the server session cookie,
/// never database credentials or passwords.
class WynApi {
  WynApi(this.prefs);
  static const baseUrl = String.fromEnvironment('WYN_API_BASE_URL');
  final SharedPreferences prefs;
  static const _cookieKey = 'wyn_api_session_cookie';

  Uri uri(String endpoint, [Map<String, String>? query]) {
    if (baseUrl.isEmpty) {
      throw Exception('عنوان API غير مضبوط. مرّر WYN_API_BASE_URL عند البناء، مثل https://example.com/api.');
    }
    final base = baseUrl.replaceAll(RegExp(r'/+$'), '');
    final u = Uri.parse('$base/$endpoint');
    return query == null ? u : u.replace(queryParameters: query);
  }

  Map<String, String> _headers({bool json = false}) {
    final h = <String, String>{'Accept': 'application/json'};
    if (json) h['Content-Type'] = 'application/json; charset=utf-8';
    final cookie = prefs.getString(_cookieKey);
    if (cookie != null && cookie.isNotEmpty) h['Cookie'] = cookie;
    return h;
  }

  Future<http.Response> _send(Future<http.Response> Function(Map<String, String>) request, {bool json = false}) async {
    final r = await request(_headers(json: json)).timeout(const Duration(seconds: 20));
    final rawCookie = r.headers['set-cookie'];
    if (rawCookie != null) {
      // Support both the site's custom session name and PHP's default session cookie.
      // Store only the cookie pair, never attributes such as Path/HttpOnly/SameSite.
      final candidates = rawCookie.split(RegExp(r',(?=[^;,]+=)'));
      for (final candidate in candidates) {
        final first = candidate.split(';').first.trim();
        if (first.startsWith('WYNSESSID=') || first.startsWith('PHPSESSID=')) {
          await prefs.setString(_cookieKey, first);
          break;
        }
      }
    }
    return r;
  }

  Map<String, dynamic> _decode(http.Response r) {
    Map<String, dynamic> data;
    try { data = jsonDecode(r.body) as Map<String, dynamic>; }
    catch (_) { throw Exception('استجابة الخادم غير مفهومة (${r.statusCode}).'); }
    if (r.statusCode < 200 || r.statusCode >= 300 || data['ok'] != true) {
      throw Exception((data['message'] ?? 'تعذر إكمال الطلب (${r.statusCode}).').toString());
    }
    return data;
  }

  Future<Map<String, dynamic>> _post(String endpoint, Map<String, dynamic> body) async {
    final r = await _send((h) => http.post(uri(endpoint), headers: h, body: jsonEncode(body)), json: true);
    return _decode(r);
  }
  Future<List<Map<String, dynamic>>> _list(String endpoint, String key) async {
    final r = await _send((h) => http.get(uri(endpoint), headers: h));
    final d = _decode(r);
    return (d[key] as List? ?? []).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  Future<Map<String, dynamic>> login(String email, String password) => _post('auth.php', {'action':'login','email':email.trim(),'password':password});
  Future<Map<String, dynamic>> register(String name, String email, String password) => _post('auth.php', {'action':'register','name':name.trim(),'email':email.trim(),'password':password});
  Future<Map<String, dynamic>> me() => _post('auth.php', {'action':'me'});
  Future<Map<String, dynamic>> updateProfile({required String name, required String email, String currentPassword = '', String newPassword = ''}) => _post('auth.php', {
    'action': 'update_profile',
    'name': name.trim(),
    'email': email.trim(),
    'current_password': currentPassword,
    'new_password': newPassword,
  });
  Future<void> logout() async { try { await _post('auth.php', {'action':'logout'}); } finally { await prefs.remove(_cookieKey); } }
  Future<List<Map<String, dynamic>>> reports() => _list('reports.php', 'reports');
  Future<Map<String, dynamic>> createReport({required int type, required double lat, required double lng}) => _post('reports.php', {'type':type,'lat':lat,'lng':lng});
  Future<void> deleteReport(String id) async { final r = await _send((h) => http.delete(uri('reports.php', {'id':id}), headers:h)); _decode(r); }
  Future<List<Map<String, dynamic>>> roadAssets() => _list('road_assets.php', 'assets');
  Future<List<Map<String, dynamic>>> placeContributions() => _list('place_contributions.php', 'contributions');
  Future<Map<String, dynamic>> createRoadAsset({required int kind, required double lat, required double lng, String? id}) => _post('road_assets.php', {'kind':kind,'lat':lat,'lng':lng,'id':id});
  Future<void> deleteRoadAsset(String id) async { final r = await _send((h) => http.delete(uri('road_assets.php', {'id':id}), headers:h)); _decode(r); }
  Future<List<Map<String, dynamic>>> trafficCells() => _list('traffic.php', 'cells');
  Future<Map<String, dynamic>> sendTraffic({required double lat, required double lng, required double speedKmh, required double accuracy}) => _post('traffic.php', {'lat':lat,'lng':lng,'speedKmh':speedKmh,'accuracy':accuracy});
  Future<Map<String, dynamic>> contributePlace({String? id, required String name, required int kind, required double lat, required double lng}) => _post('place_contributions.php', {'id':id,'name':name.trim(),'kind':kind,'lat':lat,'lng':lng});
  Future<void> deletePlaceContribution(String id) async { final r = await _send((h) => http.delete(uri('place_contributions.php', {'id':id}), headers:h)); _decode(r); }
  Future<Map<String, dynamic>> createLiveShare({required double lat, required double lng, double? heading, double? speed}) => _post('live_share.php', {'action':'create','lat':lat,'lng':lng,'heading':heading,'speed':speed});
  Future<Map<String, dynamic>> updateLiveShare({required String token, required String ownerKey, required double lat, required double lng, double? heading, double? speed}) => _post('live_share.php', {'action':'update','token':token,'owner_key':ownerKey,'lat':lat,'lng':lng,'heading':heading,'speed':speed});
  Future<Map<String, dynamic>> stopLiveShare({required String token, required String ownerKey}) => _post('live_share.php', {'action':'stop','token':token,'owner_key':ownerKey});
}
