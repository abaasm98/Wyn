import 'package:flutter_test/flutter_test.dart';
import 'package:wyn_nav_street/models/route_option.dart';

void main() {
  group('RouteOption', () {
    test('formats distance and duration labels', () {
      const short = RouteOption(geometry: [[44.3, 33.3], [44.31, 33.31]], distanceMeters: 650, durationSeconds: 900, index: 0);
      expect(short.distanceLabel, '650 م');
      expect(short.durationLabel, '15 د');

      const long = RouteOption(geometry: [[44.3, 33.3], [44.31, 33.31]], distanceMeters: 12400, durationSeconds: 3900, index: 1);
      expect(long.distanceLabel, '12.4 كم');
      expect(long.durationLabel, '1 س 5 د');
    });

    test('persists geometry, traffic score, and maneuvers', () {
      const route = RouteOption(
        geometry: [[44.3, 33.3], [44.31, 33.31]],
        distanceMeters: 1200,
        durationSeconds: 300,
        index: 2,
        trafficPenaltySeconds: 18.5,
        hasLiveTraffic: true,
        steps: [RouteStep(instruction: 'انعطف يمينًا', distanceMeters: 200, durationSeconds: 30, longitude: 44.31, latitude: 33.31, type: 'turn', modifier: 'right', name: 'شارع تجريبي')],
      );
      final restored = RouteOption.fromJson(route.toJson());
      expect(restored.geometry, route.geometry);
      expect(restored.trafficPenaltySeconds, 18.5);
      expect(restored.hasLiveTraffic, isTrue);
      expect(restored.steps.single.instruction, 'انعطف يمينًا');
      expect(restored.steps.single.maneuverLabel, 'انعطف يمينًا');
    });
  });
}
