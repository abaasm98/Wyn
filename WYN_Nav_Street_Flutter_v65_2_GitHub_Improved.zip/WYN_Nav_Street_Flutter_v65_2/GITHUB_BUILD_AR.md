# بناء WYN Nav Street v65.2 عبر GitHub Actions

1. أنشئ مستودع GitHub جديدًا وارفع **محتويات هذا المجلد** إلى جذر المستودع (يجب أن يكون `pubspec.yaml` في الجذر).
2. افتح المستودع: **Settings → Secrets and variables → Actions → New repository secret**، وأضف:
   - `MAPBOX_ACCESS_TOKEN`: مفتاح Mapbox عام يبدأ بـ `pk.`.
   - `WYN_API_BASE_URL`: رابط مجلد واجهات PHP المنشور، مثل `https://your-domain.example/api`، من دون `/` في النهاية.
3. افتح تبويب **Actions** واختر **Build WYN Nav Street Android** ثم **Run workflow**. يعمل أيضًا تلقائيًا عند الدفع إلى `main` أو `master`.
4. بعد اكتمال العملية بنجاح، افتح تفاصيل التشغيل ونزّل Artifact باسم `WYN-Nav-Street-v65.2-Android`. يحتوي على `WYN-Nav-Street.apk` للتثبيت و`WYN-Nav-Street.aab` للنشر.

## تنبيهات
- هذا المستودع يضم كود Flutter أصليًا، وليس مجرد WebView.
- مفتاح Mapbox العام يمكن استخراجه من التطبيق؛ قيّد استخدامه من لوحة Mapbox ولا تضع أي مفاتيح سرية للخادم في التطبيق.
- يجب أن يشير `WYN_API_BASE_URL` إلى API متوافق مع نقاط النهاية المستخدمة في `lib/services/wyn_api.dart`.
- نجاح بناء الحزمة لا يغني عن اختبار الخرائط وتسجيل الدخول والبلاغات والتوجيه على هاتف فعلي. هذا الملف يهيئ سير عمل البناء فقط؛ لم يُنفّذ بناء Android فعلي داخل بيئة إنشاء الحزمة.


## حدود النسخة الحالية

- GitHub Actions يشغّل `flutter analyze` و`flutter test` قبل بناء APK/AAB. نجاح البناء وحده لا يثبت صحة التكامل مع خادم PHP أو دقة الملاحة على جهاز حقيقي.
- ملفات PHP وقاعدة البيانات ليست ضمن هذا المشروع؛ يلزم التحقق من توافق `auth.php`, `reports.php`, `road_assets.php`, `place_contributions.php`, `traffic.php`, و`live_share.php` مع طلبات Flutter.
- تنزيل الخرائط وحساب المسارات دون اتصال غير منفّذين في هذه النسخة.
