import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/route_option.dart';

class PlaceResult {
  const PlaceResult(this.name, this.longitude, this.latitude);
  final String name;
  final double longitude;
  final double latitude;
}

class MapboxService {
  MapboxService(this.token);
  final String token;

  void _check() {
    if (token.isEmpty) {
      throw Exception('يلزم مفتاح Mapbox عام صالح؛ مرّره عند البناء باستخدام --dart-define=MAPBOX_ACCESS_TOKEN=pk....');
    }
  }

  Future<List<PlaceResult>> search(String query, {double? lon, double? lat}) async {
    _check();
    final params = <String, String>{
      'q': query,
      'access_token': token,
      'limit': '6',
      'language': 'ar',
      'types': 'address,place,poi,locality',
    };
    if (lon != null && lat != null) params['proximity'] = '$lon,$lat';
    final response = await http.get(Uri.https('api.mapbox.com', '/search/geocode/v6/forward', params)).timeout(const Duration(seconds: 18));
    if (response.statusCode != 200) throw Exception('تعذر البحث عن المكان (${response.statusCode}).');
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return (data['features'] as List? ?? []).whereType<Map<String, dynamic>>().map((feature) {
      final coordinates = ((feature['geometry'] as Map?)?['coordinates'] as List? ?? const [0, 0]);
      final properties = Map<String, dynamic>.from((feature['properties'] as Map?) ?? const {});
      return PlaceResult(
        (properties['full_address'] ?? properties['name'] ?? 'مكان').toString(),
        (coordinates[0] as num).toDouble(),
        (coordinates[1] as num).toDouble(),
      );
    }).toList();
  }

  Future<List<RouteOption>> routes({required double fromLon, required double fromLat, required double toLon, required double toLat}) async {
    _check();
    final coordinates = '$fromLon,$fromLat;$toLon,$toLat';

    // Match the website strategy: request traffic-aware directions first, then fall back
    // to standard driving where the traffic profile is not supported or available.
    Map<String, dynamic>? responseData;
    bool hasLiveTraffic = false;
    for (final profile in ['driving-traffic', 'driving']) {
      final params = <String, String>{
        'access_token': token,
        'alternatives': 'true',
        'geometries': 'geojson',
        'overview': 'full',
        'steps': 'true',
        'language': 'ar',
        'continue_straight': 'false',
      };
      if (profile == 'driving-traffic') params['annotations'] = 'congestion,duration,distance';
      try {
        final uri = Uri.https('api.mapbox.com', '/directions/v5/mapbox/$profile/$coordinates', params);
        final response = await http.get(uri).timeout(const Duration(seconds: 25));
        Map<String, dynamic> decoded;
        try { decoded = jsonDecode(response.body) as Map<String, dynamic>; } catch (_) { decoded = {}; }
        final valid = response.statusCode == 200 && decoded['code'] == 'Ok' && (decoded['routes'] as List? ?? []).isNotEmpty;
        if (valid) {
          responseData = decoded;
          hasLiveTraffic = profile == 'driving-traffic';
          break;
        }
      } catch (_) {
        // A transport error will be surfaced after the fallback attempt also fails.
      }
    }
    if (responseData == null) throw Exception('تعذر حساب المسار عبر Mapbox. تحقق من الإنترنت ومفتاح Directions ومن وجود طريق مدعوم بين النقطتين.');
    final rawRoutes = (responseData['routes'] as List? ?? []).whereType<Map<String, dynamic>>().toList();
    return rawRoutes.take(3).toList().asMap().entries.map((entry) {
      final route = entry.value;
      final geometryData = ((route['geometry'] as Map?)?['coordinates'] as List? ?? const []);
      final geometry = geometryData.whereType<List>().where((p) => p.length >= 2).map<List<double>>((p) => [(p[0] as num).toDouble(), (p[1] as num).toDouble()]).toList();
      final steps = <RouteStep>[];
      var trafficPenalty = 0.0;
      final legs = (route['legs'] as List? ?? []).whereType<Map>().toList();
      for (final leg in legs) {
        final legMap = Map<String, dynamic>.from(leg);
        if (hasLiveTraffic) {
          final annotation = Map<String, dynamic>.from((legMap['annotation'] as Map?) ?? const {});
          final congestion = (annotation['congestion'] as List? ?? const []).map((e) => e.toString()).toList();
          var severity = 0.0;
          var samples = 0;
          for (final level in congestion) {
            switch (level) {
              case 'low': severity += 0; samples++; break;
              case 'moderate': severity += .35; samples++; break;
              case 'heavy': severity += 1.1; samples++; break;
              case 'severe': severity += 1.8; samples++; break;
            }
          }
          if (samples > 0) trafficPenalty += (severity / samples) * ((legMap['duration'] as num? ?? 0).toDouble()) * .28;
        }
        for (final rawStep in (legMap['steps'] as List? ?? []).whereType<Map>()) {
          final step = Map<String, dynamic>.from(rawStep);
          final maneuver = Map<String, dynamic>.from((step['maneuver'] as Map?) ?? const {});
          final location = (maneuver['location'] as List? ?? const [0, 0]);
          steps.add(RouteStep(
            instruction: (maneuver['instruction'] ?? step['name'] ?? 'تابع السير').toString(),
            distanceMeters: (step['distance'] as num? ?? 0).toDouble(),
            durationSeconds: (step['duration'] as num? ?? 0).toDouble(),
            longitude: location.length > 0 ? (location[0] as num).toDouble() : 0,
            latitude: location.length > 1 ? (location[1] as num).toDouble() : 0,
            type: (maneuver['type'] ?? '').toString(),
            modifier: (maneuver['modifier'] ?? '').toString(),
            name: (step['name'] ?? '').toString(),
          ));
        }
      }
      return RouteOption(
        geometry: geometry,
        distanceMeters: (route['distance'] as num? ?? 0).toDouble(),
        durationSeconds: (route['duration'] as num? ?? 0).toDouble(),
        index: entry.key,
        steps: steps,
        trafficPenaltySeconds: trafficPenalty,
        hasLiveTraffic: hasLiveTraffic,
      );
    }).where((route) => route.geometry.length > 1).toList();
  }
}
