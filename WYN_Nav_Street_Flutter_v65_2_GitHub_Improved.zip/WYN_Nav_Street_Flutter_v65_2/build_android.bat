@echo off
setlocal
cd /d "%~dp0"
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter SDK is required. Install Flutter and Android Studio, then run this script again.
  exit /b 1
)
if "%MAPBOX_ACCESS_TOKEN%"=="" (
  echo Set MAPBOX_ACCESS_TOKEN to your public Mapbox token first.
  exit /b 1
)
if "%WYN_API_BASE_URL%"=="" (
  echo Set WYN_API_BASE_URL to the deployed WYN API base URL first.
  exit /b 1
)
if not exist "android\gradlew.bat" (
  set "TMPDIR=%TEMP%\wyn_native_backup"
  if exist "%TMPDIR%" rmdir /s /q "%TMPDIR%"
  mkdir "%TMPDIR%"
  xcopy "lib" "%TMPDIR%\lib\" /E /I /Q >nul
  copy /y pubspec.yaml "%TMPDIR%\pubspec.yaml" >nul
  if exist assets xcopy assets "%TMPDIR%\assets\" /E /I /Q >nul
  flutter create --platforms=android --org com.wyn --project-name app .
  if errorlevel 1 exit /b 1
  rmdir /s /q lib
  xcopy "%TMPDIR%\lib" lib\ /E /I /Q >nul
  copy /y "%TMPDIR%\pubspec.yaml" pubspec.yaml >nul
  if exist "%TMPDIR%\assets" (if exist assets rmdir /s /q assets & xcopy "%TMPDIR%\assets" assets\ /E /I /Q >nul)
  rmdir /s /q "%TMPDIR%"
)
if not exist "android\app\src\main\res" mkdir "android\app\src\main\res"
for %%D in (mipmap-mdpi mipmap-hdpi mipmap-xhdpi mipmap-xxhdpi mipmap-xxxhdpi) do (
  if not exist "android\app\src\main\res\%%D" mkdir "android\app\src\main\res\%%D"
  copy /y "android_res_icons\%%D\ic_launcher.png" "android\app\src\main\res\%%D\ic_launcher.png" >nul
)
if exist "android\app\src\main\res\mipmap-anydpi-v26" rmdir /s /q "android\app\src\main\res\mipmap-anydpi-v26"
copy /y android_manifest_template.xml android\app\src\main\AndroidManifest.xml >nul
call flutter pub get
if errorlevel 1 exit /b 1
call flutter build apk --release --dart-define="MAPBOX_ACCESS_TOKEN=%MAPBOX_ACCESS_TOKEN%" --dart-define="WYN_API_BASE_URL=%WYN_API_BASE_URL%"
if errorlevel 1 exit /b 1
if not exist output mkdir output
copy /y build\app\outputs\flutter-apk\app-release.apk output\WYN-Nav-Street.apk >nul
echo APK created at: %CD%\output\WYN-Nav-Street.apk
