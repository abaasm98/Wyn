import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  const token = String.fromEnvironment('MAPBOX_ACCESS_TOKEN');
  if (token.isNotEmpty) MapboxOptions.setAccessToken(token);
  final prefs = await SharedPreferences.getInstance();
  runApp(WynApp(prefs: prefs));
}

class WynApp extends StatelessWidget {
  const WynApp({super.key, required this.prefs});
  final SharedPreferences prefs;
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'وين WYN', debugShowCheckedModeBanner: false,
    locale: const Locale('ar'),
    supportedLocales: const [Locale('ar'), Locale('en')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087CF0)), scaffoldBackgroundColor: const Color(0xFFF3F6FA)),
    darkTheme: ThemeData(useMaterial3: true, brightness: Brightness.dark, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087CF0), brightness: Brightness.dark)),
    themeMode: ThemeMode.system, home: HomeScreen(prefs: prefs));
}
