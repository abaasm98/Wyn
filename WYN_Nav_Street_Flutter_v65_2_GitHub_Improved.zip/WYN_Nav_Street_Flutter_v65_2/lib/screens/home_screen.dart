import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart' as geo;
import 'package:mapbox_maps_flutter/mapbox_maps_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:share_plus/share_plus.dart';
import '../models/route_option.dart';
import '../services/location_service.dart';
import '../services/mapbox_service.dart';
import '../services/wyn_api.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key, required this.prefs}); final SharedPreferences prefs; @override State<HomeScreen> createState()=>_HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  static const token=String.fromEnvironment('MAPBOX_ACCESS_TOKEN');
  final location=LocationService(); late final WynApi api; late final mapbox=MapboxService(token); Map<String,dynamic>? user; String? liveToken, liveOwnerKey;
  MapboxMap? map; PolylineAnnotationManager? lines; PointAnnotationManager? points; CircleAnnotationManager? trafficCircles, reportCircles, assetCircles, placeCircles, userLocationCircle, destinationCircle;
  final FlutterTts tts = FlutterTts();
  StreamSubscription<geo.Position>? positionSubscription;
  Timer? clockTimer, trafficTimer, liveTimer, mapDataTimer;
  bool traffic=false, communityTrafficOptIn=true, busy=false, is3d=true, navigating=false, voiceEnabled=true, mapDark=false;
  String status='ابحث عن وجهتك';
  geo.Position? current; PlaceResult? destination; List<RouteOption> alternatives=[]; int selectedRoute=0, currentStep=0;
  DateTime? lastTrafficSent, lastReroute;
  bool appearanceInitialized = false;
  List<Map<String,dynamic>> trafficData=[], reportData=[], roadAssetData=[], placeData=[];
  List<PlaceResult> savedDestinations=[];
  @override void initState(){super.initState();api=WynApi(widget.prefs);traffic=widget.prefs.getBool('traffic_enabled')??false; communityTrafficOptIn=widget.prefs.getBool('community_traffic_optin')??true; _initTts(); _restoreUser(); _restoreLiveShare(); _loadSavedDestinations(); clockTimer=Timer.periodic(const Duration(minutes:1), (_) => _applyMapAppearance()); if(traffic) trafficTimer=Timer.periodic(const Duration(seconds:45), (_) => _refreshTrafficLayer());}
  Future<void> _initTts() async { try { await tts.setLanguage('ar'); await tts.setSpeechRate(.47); await tts.setVolume(1); await tts.setPitch(1); } catch (_) {} }
  Future<void> _restoreUser() async { try { final d=await api.me(); if(mounted)setState(()=>user=d['user'] as Map<String,dynamic>?); } catch (_) {} }
  Future<void> _restoreLiveShare() async { final t=widget.prefs.getString('wyn_live_token'), k=widget.prefs.getString('wyn_live_owner'); if(t!=null&&k!=null&&t.isNotEmpty&&k.isNotEmpty){liveToken=t;liveOwnerKey=k; try { current=await location.currentPosition(); await _ensurePositionStream(); liveTimer=Timer.periodic(const Duration(seconds:11), (_) async { final p=current; final token=liveToken; final key=liveOwnerKey; if(p==null||token==null||key==null)return; try { await api.updateLiveShare(token:token,ownerKey:key,lat:p.latitude,lng:p.longitude,heading:p.heading.isFinite?p.heading:null,speed:p.speed.isFinite?math.max(0,p.speed).toDouble():null); } catch (_) {} }); } catch (_) {} } }
  Future<void> onMapCreated(MapboxMap m) async { map=m; lines=await m.annotations.createPolylineAnnotationManager(); points=await m.annotations.createPointAnnotationManager(); trafficCircles=await m.annotations.createCircleAnnotationManager(); reportCircles=await m.annotations.createCircleAnnotationManager(); assetCircles=await m.annotations.createCircleAnnotationManager(); placeCircles=await m.annotations.createCircleAnnotationManager(); userLocationCircle=await m.annotations.createCircleAnnotationManager(); destinationCircle=await m.annotations.createCircleAnnotationManager(); await m.compass.updateSettings(const CompassSettings(enabled:true)); await m.scaleBar.updateSettings(const ScaleBarSettings(enabled:false)); await _applyMapAppearance(); if(is3d) await _set3d(true); if(traffic) { await _setMapboxTrafficOverlay(true); await _refreshTrafficLayer(); } await _refreshSharedMapData(); mapDataTimer=Timer.periodic(const Duration(seconds:60), (_) => _refreshSharedMapData()); if(current==null) { await _locate(); } else { await _updateUserLocationMarker(current!); } if(destination!=null) await _updateDestinationMarker(destination!); if(alternatives.isNotEmpty) await _drawRoutes(); Future<void>.delayed(const Duration(seconds:2), () async { if(!mounted || map==null)return; await _applyMapAppearance(); if(traffic) await _setMapboxTrafficOverlay(true); if(destination!=null) await _updateDestinationMarker(destination!); if(current!=null) await _updateUserLocationMarker(current!); }); }
  Future<void> _applyMapAppearance() async { if(map==null)return; final hour=DateTime.now().hour; final systemDark=WidgetsBinding.instance.platformDispatcher.platformBrightness==Brightness.dark; final dark=systemDark || hour>=19 || hour<6; if(appearanceInitialized && dark==mapDark) return; try { await map!.style.setStyleImportConfigProperty('basemap','lightPreset',dark?'night':'day'); await map!.style.setStyleImportConfigProperty('basemap','show3dObjects',is3d); mapDark=dark; appearanceInitialized=true; } catch (_) { Future<void>.delayed(const Duration(seconds:2), () { if(mounted) _applyMapAppearance(); }); } }
  Future<void> _set3d(bool value) async { if(map==null){setState(()=>is3d=value);return;} setState(()=>is3d=value); try { await map!.style.setStyleImportConfigProperty('basemap','show3dObjects',value); await map!.easeTo(CameraOptions(pitch:value?55:0),MapAnimationOptions(duration:700)); } catch (_) {} }
  Future<void> _locate() async { try { setState(()=>busy=true); current=await location.currentPosition(); await _updateUserLocationMarker(current!); await map?.flyTo(CameraOptions(center:Point(coordinates:Position(current!.longitude,current!.latitude)),zoom:16,pitch:is3d?50:0),MapAnimationOptions(duration:900)); if(mounted)setState(()=>status='تم تحديد موقعك'); } catch(e){_message(e.toString().replaceFirst('Exception: ',''));} finally{if(mounted)setState(()=>busy=false);} }
  Future<void> _loadSavedDestinations() async {
    try {
      final raw = widget.prefs.getString('wyn_saved_destinations');
      if (raw != null) {
        final list = jsonDecode(raw) as List;
        savedDestinations = list.whereType<Map>().map((e) => PlaceResult((e['name'] ?? 'مكان محفوظ').toString(), (e['longitude'] as num).toDouble(), (e['latitude'] as num).toDouble())).toList();
      }
      final last = widget.prefs.getString('wyn_last_destination');
      if (last != null && destination == null) {
        final item = jsonDecode(last) as Map;
        destination = PlaceResult((item['name'] ?? '').toString(), (item['longitude'] as num).toDouble(), (item['latitude'] as num).toDouble());
      }
      final savedRoute = widget.prefs.getString('wyn_last_route');
      if (savedRoute != null) {
        final data = jsonDecode(savedRoute) as Map<String,dynamic>;
        final target = data['destination'] as Map?;
        if (target != null) destination = PlaceResult((target['name'] ?? '').toString(), (target['longitude'] as num).toDouble(), (target['latitude'] as num).toDouble());
        alternatives = (data['routes'] as List? ?? const []).whereType<Map>().map((e)=>RouteOption.fromJson(Map<String,dynamic>.from(e))).toList();
        selectedRoute = ((data['selectedRoute'] as num?)?.toInt() ?? 0).clamp(0, math.max(0, alternatives.length-1)).toInt();
      }
      if (mounted) setState(() {});
      if (map != null && destination != null) { await _updateDestinationMarker(destination!); if (alternatives.isNotEmpty) await _drawRoutes(); }
    } catch (_) {}
  }

  Future<void> _saveDestination() async {
    final p = destination;
    if (p == null) return;
    final exists = savedDestinations.any((item) => item.name == p.name && (item.longitude-p.longitude).abs() < .0001 && (item.latitude-p.latitude).abs() < .0001);
    if (exists) { _message('الوجهة محفوظة مسبقًا.'); return; }
    savedDestinations.insert(0, p);
    if (savedDestinations.length > 30) savedDestinations = savedDestinations.take(30).toList();
    await widget.prefs.setString('wyn_saved_destinations', jsonEncode(savedDestinations.map((e) => {'name':e.name,'longitude':e.longitude,'latitude':e.latitude}).toList()));
    if (mounted) setState(() {});
    _message('تم حفظ الوجهة على هذا الجهاز.');
  }

  Future<void> _persistRoute() async {
    final target = destination;
    if (target == null || alternatives.isEmpty) return;
    try {
      await widget.prefs.setString('wyn_last_route', jsonEncode({
        'destination': {'name':target.name,'longitude':target.longitude,'latitude':target.latitude},
        'selectedRoute':selectedRoute,
        'routes':alternatives.map((r)=>r.toJson()).toList(),
      }));
    } catch (_) {}
  }

  Future<void> _searchDestination() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => PlaceSearchSheet(
        service: mapbox,
        current: current,
        savedPlaces: savedDestinations,
        onSelect: (place) {
          Navigator.of(ctx).pop();
          _buildRoutes(place);
        },
      ),
    );
  }
  Future<void> _buildRoutes(PlaceResult p) async { try { setState(()=>busy=true); current??=await location.currentPosition(); destination=p; await widget.prefs.setString('wyn_last_destination', jsonEncode({'name':p.name,'longitude':p.longitude,'latitude':p.latitude})); await _updateDestinationMarker(p); try { final data=await Future.wait([api.reports(),api.roadAssets(),api.trafficCells()]); reportData=data[0]; roadAssetData=data[1]; trafficData=data[2]; } catch (_) {} alternatives=await mapbox.routes(fromLon:current!.longitude,fromLat:current!.latitude,toLon:p.longitude,toLat:p.latitude); if(alternatives.isEmpty)throw Exception('لا توجد مسارات متاحة.'); final scored = alternatives.map((r) => (route: r, score: r.durationSeconds + _routePenalty(r))).toList(); scored.sort((a,b) => a.score.compareTo(b.score)); alternatives = scored.map((e) => e.route).toList(); selectedRoute=0; await _persistRoute(); await _drawRoutes(); await _showRouteSheet(); } catch(e){_message(e.toString().replaceFirst('Exception: ',''));} finally{if(mounted)setState(()=>busy=false);} }
  Future<void> _drawRoutes() async { if(lines==null)return; await lines!.deleteAll(); for(var i=alternatives.length-1;i>=0;i--){final r=alternatives[i]; final color=i==selectedRoute?const Color(0xFF087CF0):const Color(0xFF8393A8); await lines!.create(PolylineAnnotationOptions(geometry:LineString(coordinates:r.geometry.map((p)=>Position(p[0],p[1])).toList()),lineColor:color.value,lineWidth:i==selectedRoute?7:4,lineOpacity:i==selectedRoute?1:0.68));} if(alternatives.isNotEmpty){final coords=alternatives[selectedRoute].geometry; final lons=coords.map((p)=>p[0]).toList(); final lats=coords.map((p)=>p[1]).toList(); final minLon=lons.reduce((a,b)=>a<b?a:b),maxLon=lons.reduce((a,b)=>a>b?a:b),minLat=lats.reduce((a,b)=>a<b?a:b),maxLat=lats.reduce((a,b)=>a>b?a:b); await map?.cameraForCoordinateBounds(CoordinateBounds(southwest:Point(coordinates:Position(minLon,minLat)),northeast:Point(coordinates:Position(maxLon,maxLat)),infiniteBounds:false),MbxEdgeInsets(top:120,left:45,bottom:230,right:45),null,null).then((c)=>map?.flyTo(c,MapAnimationOptions(duration:900)));} }
  Future<void> _showRouteSheet() async { if(!mounted)return; await showModalBottomSheet<void>(context:context,isScrollControlled:true,builder:(ctx)=>StatefulBuilder(builder:(ctx,setSheet)=>SafeArea(child:Padding(padding:const EdgeInsets.all(16),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[Text(destination?.name??'المسارات',maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:8),...alternatives.asMap().entries.map((e){final r=e.value;return Card(color:e.key==selectedRoute?Theme.of(ctx).colorScheme.primaryContainer:null,child:ListTile(leading:Icon(e.key==0?Icons.bolt:Icons.alt_route),title:Text(e.key==0?'المسار ${e.key+1} · المقترح':'المسار ${e.key+1}'),subtitle:Text('${r.durationLabel}  •  ${r.distanceLabel}'),trailing:e.key==selectedRoute?const Icon(Icons.check_circle):null,onTap:(){setState(()=>selectedRoute=e.key);this.setState(()=>selectedRoute=e.key);_persistRoute();_drawRoutes();}));}),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:(){Navigator.pop(ctx);setState(()=>status='المسار محدد: ${alternatives[selectedRoute].durationLabel}');},icon:const Icon(Icons.navigation),label:const Text('اختيار هذا المسار')))]))))); }
  Future<void> _updateUserLocationMarker(geo.Position p) async {
    final manager = userLocationCircle;
    if (manager == null) return;
    try {
      await manager.deleteAll();
      await manager.create(CircleAnnotationOptions(geometry: Point(coordinates: Position(p.longitude, p.latitude)), circleRadius: 9, circleColor: const Color(0xFF1769FF).value, circleOpacity: 1, circleStrokeColor: Colors.white.value, circleStrokeWidth: 3));
    } catch (_) {}
  }

  Future<void> _updateDestinationMarker(PlaceResult p) async {
    final manager = destinationCircle;
    if (manager == null) return;
    try {
      await manager.deleteAll();
      await manager.create(CircleAnnotationOptions(geometry: Point(coordinates: Position(p.longitude, p.latitude)), circleRadius: 10, circleColor: const Color(0xFF16A34A).value, circleOpacity: 1, circleStrokeColor: Colors.white.value, circleStrokeWidth: 3));
    } catch (_) {}
  }

  String _maneuverStatus() {
    if (!navigating || alternatives.isEmpty) return status;
    final steps = alternatives[selectedRoute].steps;
    if (steps.isEmpty || currentStep >= steps.length) return 'تابع الطريق إلى ${destination?.name ?? 'وجهتك'}';
    final step = steps[currentStep];
    final distance = current == null ? 0.0 : geo.Geolocator.distanceBetween(current!.latitude, current!.longitude, step.latitude, step.longitude);
    final distanceText = distance >= 1000 ? '${(distance / 1000).toStringAsFixed(1)} كم' : '${distance.round()} م';
    return '${step.maneuverLabel} بعد $distanceText${step.name.isNotEmpty ? ' · ${step.name}' : ''}';
  }

  Future<void> _speak(String text) async {
    if (!voiceEnabled || !navigating || text.trim().isEmpty) return;
    try { await tts.stop(); await tts.speak(text); } catch (_) {}
  }

  Future<void> _startNavigation() async {
    if (alternatives.isEmpty || destination == null) { await _searchDestination(); return; }
    try {
      setState(() => busy = true);
      current ??= await location.currentPosition();
      setState(() { navigating = true; currentStep = alternatives[selectedRoute].steps.length > 1 ? 1 : 0; status = 'بدأت الملاحة'; });
      await _ensurePositionStream();
      final pos = current!;
      await map?.easeTo(CameraOptions(center: Point(coordinates: Position(pos.longitude, pos.latitude)), zoom: 17, pitch: is3d ? 58 : 0, bearing: pos.heading.isFinite && pos.speed > 1 ? pos.heading : null), MapAnimationOptions(duration: 800));
      await _speak('بدأت الملاحة إلى ${destination!.name}. ${_currentInstruction()}');
      if (mounted) setState(() => status = 'الملاحة نشطة · ${alternatives[selectedRoute].durationLabel}');
    } catch (e) { if (mounted) setState(() => navigating = false); _message(e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => busy = false); }
  }

  String _currentInstruction() {
    if (alternatives.isEmpty) return 'تابع الطريق';
    final steps = alternatives[selectedRoute].steps;
    if (steps.isEmpty) return 'تابع المسار';
    final i = currentStep.clamp(0, steps.length - 1).toInt();
    return steps[i].instruction;
  }

  Future<void> _stopNavigation() async {
    setState(() { navigating = false; status = 'تم إنهاء الملاحة'; });
    try { await tts.stop(); } catch (_) {}
    if (liveToken == null) { await positionSubscription?.cancel(); positionSubscription = null; }
    await map?.easeTo(CameraOptions(pitch: is3d ? 35 : 0), MapAnimationOptions(duration: 500));
  }

  Future<void> _ensurePositionStream() async {
    if (positionSubscription != null) return;
    positionSubscription = geo.Geolocator.getPositionStream(locationSettings: const geo.LocationSettings(accuracy: geo.LocationAccuracy.bestForNavigation, distanceFilter: 6)).listen((p) { _onPosition(p); }, onError: (Object e) { if (mounted) _message('توقف تحديث GPS: $e'); });
  }

  Future<void> _onPosition(geo.Position p) async {
    current = p;
    await _updateUserLocationMarker(p);
    if (mounted) setState(() {});
    if (!navigating) return;
    if (p.accuracy <= 70 && alternatives.isNotEmpty) {
      final route = alternatives[selectedRoute];
      if (route.steps.isNotEmpty && currentStep < route.steps.length) {
        final step = route.steps[currentStep];
        final distance = geo.Geolocator.distanceBetween(p.latitude, p.longitude, step.latitude, step.longitude);
        if (distance < math.max(35, p.speed * 2.4) && currentStep < route.steps.length - 1) {
          currentStep++;
          await _speak(_currentInstruction());
        }
      }
      if (route.steps.isNotEmpty && currentStep >= route.steps.length - 1) {
        final finalStep = route.steps.last;
        final toEnd = geo.Geolocator.distanceBetween(p.latitude, p.longitude, finalStep.latitude, finalStep.longitude);
        if (toEnd < 28) { await _speak('وصلت إلى وجهتك.'); Future<void>.delayed(const Duration(seconds: 3), () { if (mounted) _stopNavigation(); }); return; }
      }
      if (lastReroute == null || DateTime.now().difference(lastReroute!).inSeconds > 30) {
        final distance = _distanceToActiveRoute(p, route.geometry);
        if (distance > 85) { lastReroute = DateTime.now(); await _rerouteFromCurrent(p); }
      }
      final now = DateTime.now();
      if (communityTrafficOptIn && p.accuracy <= 45 && (lastTrafficSent == null || now.difference(lastTrafficSent!).inSeconds >= 25)) {
        lastTrafficSent = now;
        final speed = p.speed.isFinite ? (p.speed * 3.6).clamp(0, 180).toDouble() : 0.0;
        try { await api.sendTraffic(lat: p.latitude, lng: p.longitude, speedKmh: speed, accuracy: p.accuracy); } catch (_) {}
      }
    }
    if (map != null) {
      try {
        await map!.easeTo(CameraOptions(center: Point(coordinates: Position(p.longitude, p.latitude)), zoom: 17, pitch: is3d ? 58 : 0, bearing: p.speed > 1.4 && p.heading.isFinite ? p.heading : null), MapAnimationOptions(duration: 550));
      } catch (_) {}
    }
  }

  double _distanceToActiveRoute(geo.Position p, List<List<double>> geometry) {
    if (geometry.isEmpty) return 999999;
    var best = double.infinity;
    // Sample every few points to keep GPS updates inexpensive on long routes.
    for (var i = 0; i < geometry.length; i += 4) {
      final c = geometry[i];
      final d = geo.Geolocator.distanceBetween(p.latitude, p.longitude, c[1], c[0]);
      if (d < best) best = d;
      if (best < 20) break;
    }
    final last = geometry.last;
    final dLast = geo.Geolocator.distanceBetween(p.latitude, p.longitude, last[1], last[0]);
    return math.min(best, dLast).toDouble();
  }

  Future<void> _rerouteFromCurrent(geo.Position p) async {
    final target = destination;
    if (target == null) return;
    try {
      if (mounted) setState(() => status = 'خرجت عن المسار؛ جارٍ إعادة التوجيه…');
      final routes = await mapbox.routes(fromLon: p.longitude, fromLat: p.latitude, toLon: target.longitude, toLat: target.latitude);
      if (routes.isEmpty) return;
      final scored = routes.map((r) => (route: r, score: r.durationSeconds + _routePenalty(r))).toList(); scored.sort((a,b) => a.score.compareTo(b.score));
      alternatives = scored.map((e) => e.route).toList();
      selectedRoute = 0;
      currentStep = alternatives.first.steps.length > 1 ? 1 : 0;
      await _persistRoute();
      await _drawRoutes();
      await _speak('تم تحديث المسار. ${_currentInstruction()}');
      if (mounted) setState(() => status = 'تم تحديث المسار تلقائيًا');
    } catch (_) { if (mounted) setState(() => status = 'تعذر تحديث المسار؛ تابع بحذر'); }
  }

  Future<void> _setMapboxTrafficOverlay(bool enabled) async {
    final m = map;
    if (m == null) return;
    const sourceId = 'wyn-mapbox-traffic-source';
    const lineIds = ['wyn-mapbox-traffic-low','wyn-mapbox-traffic-moderate','wyn-mapbox-traffic-heavy','wyn-mapbox-traffic-severe','wyn-mapbox-traffic-arrows'];
    try {
      if (!enabled) {
        for (final id in lineIds.reversed) { try { await m.style.removeStyleLayer(id); } catch (_) {} }
        try { await m.style.removeStyleSource(sourceId); } catch (_) {}
        return;
      }
      try { await m.style.addStyleSource(sourceId, jsonEncode({'type':'vector','url':'mapbox://mapbox.mapbox-traffic-v1'})); } catch (_) { /* Already exists or this token lacks the traffic tileset. */ }
      const levels = <String, int>{'low':0xFF18A66A,'moderate':0xFFE6A817,'heavy':0xFFF06A2B,'severe':0xFFE12D39};
      for (final entry in levels.entries) {
        final id = 'wyn-mapbox-traffic-${entry.key}';
        final layer = {
          'id': id, 'type':'line', 'source':sourceId, 'source-layer':'traffic', 'slot':'middle',
          'filter':['==',['get','congestion'],entry.key],
          'layout':{'line-cap':'round','line-join':'round'},
          'paint':{'line-color':'#${entry.value.toRadixString(16).substring(2)}','line-opacity':0.96,'line-width':['interpolate',['linear'],['zoom'],8,1.8,11,2.8,14,4.4,17,7.2,20,10.0]},
        };
        try { await m.style.addStyleLayer(jsonEncode(layer), null); } catch (_) { /* Existing layer / unsupported traffic source. */ }
      }
      final arrows = {
        'id':'wyn-mapbox-traffic-arrows','type':'symbol','source':sourceId,'source-layer':'traffic','slot':'middle','filter':['has','congestion'],
        'layout':{'symbol-placement':'line','symbol-spacing':['interpolate',['linear'],['zoom'],8,120,12,90,16,66,19,54],'text-field':'➤','text-font':['Open Sans Semibold','Arial Unicode MS Regular'],'text-size':['interpolate',['linear'],['zoom'],7,10,12,13,16,16,19,19],'text-rotation-alignment':'map','text-pitch-alignment':'map','text-keep-upright':false,'text-allow-overlap':true,'text-ignore-placement':true},
        'paint':{'text-color':['match',['get','congestion'],'low','#087747','moderate','#805400','heavy','#A33B12','severe','#FFFFFF','#2563EB'],'text-halo-color':mapDark?'#172332':'#FFFFFF','text-halo-width':1.35},
      };
      try { await m.style.addStyleLayer(jsonEncode(arrows), null); } catch (_) {}
    } catch (_) {
      if (mounted && enabled) _message('طبقة المرور الحي من Mapbox غير متاحة لهذا النمط أو المفتاح؛ يستمر عرض المرور المجتمعي عند توفره.');
    }
  }

  Future<void> _refreshTrafficLayer() async {
    if (!traffic || trafficCircles == null) return;
    try {
      final cells = await api.trafficCells();
      trafficData = cells;
      await trafficCircles!.deleteAll();
      // The community API returns coarse, privacy-preserving ~100 m cells. Draw them as
      // compact speed-coded native map circles; never fabricate traffic on unknown roads.
      for (final cell in cells.take(350)) {
        final lat = (cell['lat'] as num?)?.toDouble();
        final lng = (cell['lng'] as num?)?.toDouble();
        final speed = (cell['speedKmh'] as num?)?.toDouble();
        if (lat == null || lng == null || speed == null) continue;
        if (current != null && geo.Geolocator.distanceBetween(current!.latitude, current!.longitude, lat, lng) > 35000) continue;
        final color = speed < 12 ? const Color(0xFFE53935) : speed < 28 ? const Color(0xFFFF8F00) : speed < 48 ? const Color(0xFFFDD835) : const Color(0xFF43A047);
        await trafficCircles!.create(CircleAnnotationOptions(geometry: Point(coordinates: Position(lng, lat)), circleRadius: speed < 12 ? 8 : 6, circleColor: color.value, circleOpacity: .88, circleStrokeColor: Colors.white.value, circleStrokeWidth: 1.2));
      }
      if (mounted) setState(() {});
    } catch (e) { if (mounted && trafficData.isEmpty) _message('تعذر تحميل الحركة المرورية المجتمعية.'); }
  }

  Future<void> _refreshSharedMapData() async {
    if (map == null) return;
    try {
      final results = await Future.wait([
        api.reports(), api.roadAssets(), api.placeContributions(),
      ]);
      reportData = results[0]; roadAssetData = results[1]; placeData = results[2];
      await reportCircles?.deleteAll(); await assetCircles?.deleteAll(); await placeCircles?.deleteAll();
      for (final item in reportData.take(180)) {
        final pos = item['pos'] as Map?; final lat = (pos?['lat'] as num?)?.toDouble(); final lng = (pos?['lng'] as num?)?.toDouble();
        if (lat == null || lng == null || !_isNearby(lat, lng, 50000)) continue;
        await reportCircles?.create(CircleAnnotationOptions(geometry: Point(coordinates: Position(lng, lat)), circleRadius: 8, circleColor: const Color(0xFFEF4444).value, circleOpacity: .94, circleStrokeColor: Colors.white.value, circleStrokeWidth: 1.5));
      }
      for (final item in roadAssetData.take(180)) {
        final pos = item['pos'] as Map?; final lat = (pos?['lat'] as num?)?.toDouble(); final lng = (pos?['lng'] as num?)?.toDouble();
        if (lat == null || lng == null || !_isNearby(lat, lng, 50000)) continue;
        final kind = (item['kind'] as num?)?.toInt() ?? 0;
        final color = kind == 0 ? const Color(0xFF7C3AED) : kind == 1 ? const Color(0xFF2563EB) : const Color(0xFF0D9488);
        await assetCircles?.create(CircleAnnotationOptions(geometry: Point(coordinates: Position(lng, lat)), circleRadius: 6.5, circleColor: color.value, circleOpacity: .95, circleStrokeColor: Colors.white.value, circleStrokeWidth: 1.3));
      }
      for (final item in placeData.take(180)) {
        final pos = item['pos'] as Map?; final lat = (pos?['lat'] as num?)?.toDouble(); final lng = (pos?['lng'] as num?)?.toDouble();
        if (lat == null || lng == null || !_isNearby(lat, lng, 50000)) continue;
        await placeCircles?.create(CircleAnnotationOptions(geometry: Point(coordinates: Position(lng, lat)), circleRadius: 5.5, circleColor: const Color(0xFF0891B2).value, circleOpacity: .95, circleStrokeColor: Colors.white.value, circleStrokeWidth: 1));
      }
      if (mounted) setState(() {});
    } catch (_) { /* Map remains usable if one optional community endpoint is unavailable. */ }
  }

  bool _isNearby(double lat, double lng, double radiusMeters) {
    if (current == null) return true;
    return geo.Geolocator.distanceBetween(current!.latitude, current!.longitude, lat, lng) <= radiusMeters;
  }

  double _routePenalty(RouteOption route) {
    var penalty = route.trafficPenaltySeconds + route.distanceMeters / 1000 * .35;
    for (final report in reportData) {
      final pos = report['pos'] as Map?; final lat = (pos?['lat'] as num?)?.toDouble(); final lng = (pos?['lng'] as num?)?.toDouble();
      if (lat == null || lng == null) continue;
      final distance = _distanceToRoutePoint(lat, lng, route.geometry);
      if (distance < 180) {
        final type = (report['type'] as num?)?.toInt() ?? 0;
        penalty += switch (type) { 1 => 280, 2 => 210, 4 => 180, 5 => 250, 6 => 300, 7 => 180, 8 => 130, _ => 60 };
      }
    }
    for (final asset in roadAssetData) {
      final pos = asset['pos'] as Map?; final lat = (pos?['lat'] as num?)?.toDouble(); final lng = (pos?['lng'] as num?)?.toDouble();
      if (lat == null || lng == null) continue;
      final kind = (asset['kind'] as num?)?.toInt() ?? 0;
      final assetPenalty = kind == 2 ? 28.0 : 0.0;
      if (assetPenalty > 0 && _distanceToRoutePoint(lat, lng, route.geometry) < 150) penalty += assetPenalty;
    }
    for (final cell in trafficData) {
      final lat = (cell['lat'] as num?)?.toDouble(); final lng = (cell['lng'] as num?)?.toDouble(); final speed = (cell['speedKmh'] as num?)?.toDouble() ?? 50; final samples = (cell['samples'] as num?)?.toInt() ?? 0; final age = (cell['ageSeconds'] as num?)?.toInt() ?? 600;
      if (lat == null || lng == null || samples < 3 || age > 600 || speed >= 35) continue;
      if (_distanceToRoutePoint(lat, lng, route.geometry) < 140) penalty += ((35 - speed) * 4 * (samples >= 10 ? 1 : .6) * math.max(.2, 1 - age / 600)).toDouble();
    }
    return penalty.clamp(0, 1200).toDouble();
  }

  double _distanceToRoutePoint(double lat, double lng, List<List<double>> geometry) {
    var best = double.infinity;
    for (var i = 0; i < geometry.length; i += 5) {
      final c = geometry[i];
      final d = geo.Geolocator.distanceBetween(lat, lng, c[1], c[0]);
      if (d < best) best = d;
      if (best < 30) break;
    }
    return best;
  }

  Future<void> _toggleTraffic() async {
    final enabled = !traffic;
    setState(() => traffic = enabled);
    await widget.prefs.setBool('traffic_enabled', enabled);
    trafficTimer?.cancel();
    if (enabled) {
      await _setMapboxTrafficOverlay(true);
      await _refreshTrafficLayer();
      trafficTimer = Timer.periodic(const Duration(seconds: 45), (_) => _refreshTrafficLayer());
      _message('تم تفعيل المرور المجتمعي. تظهر الخلايا التي اجتازت حدّ الثقة فقط.');
    } else {
      await _setMapboxTrafficOverlay(false);
      await trafficCircles?.deleteAll();
      trafficData.clear();
      _message('تم إيقاف عرض الحركة المرورية.');
    }
  }

  Future<void> _reports() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: api.reports(),
            builder: (ctx, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const SizedBox(height: 180, child: Center(child: CircularProgressIndicator()));
              }
              if (snapshot.hasError) {
                return SizedBox(
                  height: 180,
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text(snapshot.error.toString()),
                    TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إغلاق')),
                  ]),
                );
              }
              final items = snapshot.data ?? [];
              return SizedBox(
                height: MediaQuery.of(ctx).size.height * .62,
                child: Column(children: [
                  Row(children: [
                    const Expanded(child: Text('البلاغات المرورية', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                    IconButton(onPressed: _newReport, icon: const Icon(Icons.add_alert), tooltip: 'إضافة بلاغ'),
                  ]),
                  const SizedBox(height: 8),
                  Expanded(
                    child: items.isEmpty
                        ? const Center(child: Text('لا توجد بلاغات حالية.'))
                        : ListView.builder(
                            itemCount: items.length,
                            itemBuilder: (ctx, i) {
                              final report = items[i];
                              final pos = (report['pos'] as Map<String, dynamic>?) ?? <String, dynamic>{};
                              return ListTile(
                                leading: const Icon(Icons.warning_amber_rounded),
                                title: Text(_reportName(report['type'])),
                                subtitle: Text('${pos['lat'] ?? ''}, ${pos['lng'] ?? ''}'),
                                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                                  IconButton(icon: const Icon(Icons.near_me), tooltip: 'عرض على الخريطة', onPressed: () { Navigator.pop(ctx); final lat=(pos['lat'] as num?)?.toDouble(); final lng=(pos['lng'] as num?)?.toDouble(); if(lat!=null&&lng!=null) map?.flyTo(CameraOptions(center:Point(coordinates:Position(lng,lat)),zoom:16),MapAnimationOptions(duration:700)); }),
                                  if (report['canDelete'] == true) IconButton(icon: const Icon(Icons.delete_outline), tooltip: 'حذف البلاغ', onPressed: () async { try { await api.deleteReport(report['id'].toString()); if(ctx.mounted) Navigator.pop(ctx); _message('تم حذف البلاغ.'); } catch(e) { _message(e.toString().replaceFirst('Exception: ','')); } }),
                                ]),
                              );
                            },
                          ),
                  ),
                ]),
              );
            },
          ),
        ),
      ),
    );
  }

  Future<void> _newReport() async {
    if (user == null) {
      _message('سجّل الدخول أولاً لإضافة بلاغ.');
      await _account();
      return;
    }
    try {
      current ??= await location.currentPosition();
      final types = <int, String>{
        0: 'بلاغ آخر', 1: 'حادث مروري', 2: 'رادار', 3: 'نقطة تفتيش',
        4: 'ازدحام', 5: 'خطر على الطريق', 6: 'إغلاق طريق', 7: 'كاميرا', 8: 'إشارة مرورية',
      };
      final type = await showModalBottomSheet<int>(
        context: context,
        builder: (ctx) => SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: types.entries.map((entry) => ListTile(
              leading: const Icon(Icons.report_problem_outlined),
              title: Text(entry.value),
              onTap: () => Navigator.pop(ctx, entry.key),
            )).toList(),
          ),
        ),
      );
      if (type == null) return;
      final result = await api.createReport(type: type, lat: current!.latitude, lng: current!.longitude);
      await _refreshSharedMapData(); await _restoreUser(); _message('تم إرسال البلاغ بنجاح${result['xp'] != null ? ' وإضافة نقاط XP' : ''}.');
    } catch (e) {
      _message(e.toString().replaceFirst('Exception: ', ''));
    }
  }

  Future<void> _account() async {
    final name = TextEditingController(text: user?['name']?.toString() ?? '');
    final email = TextEditingController(text: user?['email']?.toString() ?? '');
    final password = TextEditingController();
    bool register = false;
    bool working = false;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(children: [
                  const Expanded(child: Text('حساب WYN', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
                  IconButton(onPressed: () => Navigator.pop(ctx), icon: const Icon(Icons.close)),
                ]),
                SwitchListTile(contentPadding: EdgeInsets.zero, value: communityTrafficOptIn, title: const Text('المساهمة المرورية المجتمعية'), subtitle: const Text('إرسال عينات سرعة GPS أثناء الملاحة فقط'), onChanged: (value) async { setSheet(() => communityTrafficOptIn = value); await widget.prefs.setBool('community_traffic_optin', value); _message(value ? 'تم تفعيل المساهمة المرورية أثناء الملاحة.' : 'تم إيقاف إرسال عينات المرور.'); }),
                if (user != null) ...[
                  Text('مرحباً ${user!['name'] ?? ''}', style: const TextStyle(fontSize: 17)),
                  const SizedBox(height: 6),
                  Text('مجموع النقاط: ${user!['xp'] ?? 0}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  if ((user!['xpHistory'] as List?)?.isNotEmpty == true) ...[
                    const SizedBox(height: 8),
                    const Align(alignment: Alignment.centerRight, child: Text('آخر نشاطات النقاط', style: TextStyle(fontWeight: FontWeight.w600))),
                    ...((user!['xpHistory'] as List).take(4).map((raw) { final entry = raw as Map; return ListTile(dense: true, contentPadding: EdgeInsets.zero, leading: const Icon(Icons.stars_outlined, size: 20), title: Text((entry['description'] ?? 'نشاط').toString(), maxLines: 1, overflow: TextOverflow.ellipsis), trailing: Text('+${entry['points'] ?? 0} XP')); })),
                  ],
                  const SizedBox(height: 12),
                  OutlinedButton.icon(onPressed: () async { if (ctx.mounted) Navigator.pop(ctx); await _editProfile(); }, icon: const Icon(Icons.manage_accounts_outlined), label: const Text('تعديل الملف الشخصي')),
                  OutlinedButton.icon(onPressed: () async { if (ctx.mounted) Navigator.pop(ctx); await _myContributions(); }, icon: const Icon(Icons.layers_outlined), label: const Text('مساهماتي على الخريطة')),
                  const SizedBox(height: 8),
                  FilledButton.tonal(
                    onPressed: working ? null : () async {
                      setSheet(() => working = true);
                      try {
                        await api.logout();
                        if (mounted) setState(() => user = null);
                        if (ctx.mounted) Navigator.pop(ctx);
                        _message('تم تسجيل الخروج.');
                      } catch (e) {
                        _message(e.toString());
                      } finally {
                        if (ctx.mounted) setSheet(() => working = false);
                      }
                    },
                    child: const Text('تسجيل الخروج'),
                  ),
                ] else ...[
                  if (register) TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم', prefixIcon: Icon(Icons.person_outline))),
                  TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'البريد الإلكتروني', prefixIcon: Icon(Icons.email_outlined))),
                  TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور (6 أحرف على الأقل)', prefixIcon: Icon(Icons.lock_outline))),
                  const SizedBox(height: 14),
                  FilledButton(
                    onPressed: working ? null : () async {
                      setSheet(() => working = true);
                      try {
                        final result = register
                            ? await api.register(name.text, email.text, password.text)
                            : await api.login(email.text, password.text);
                        if (mounted) setState(() => user = result['user'] as Map<String, dynamic>?);
                        if (ctx.mounted) Navigator.pop(ctx);
                        _message(register ? 'تم إنشاء الحساب وتسجيل الدخول.' : 'تم تسجيل الدخول.');
                      } catch (e) {
                        _message(e.toString().replaceFirst('Exception: ', ''));
                      } finally {
                        if (ctx.mounted) setSheet(() => working = false);
                      }
                    },
                    child: working ? const CircularProgressIndicator() : Text(register ? 'إنشاء حساب' : 'تسجيل الدخول'),
                  ),
                  TextButton(
                    onPressed: () => setSheet(() => register = !register),
                    child: Text(register ? 'لديك حساب؟ سجّل الدخول' : 'مستخدم جديد؟ إنشاء حساب'),
                  ),
                ],
                const SizedBox(height: 8),
                OutlinedButton.icon(onPressed: () { Navigator.pop(ctx); _shareLocation(); }, icon: const Icon(Icons.share_location), label: const Text('مشاركة موقعي المباشرة')),
              ],
            ),
          ),
        ),
      ),
    );
    name.dispose();
    email.dispose();
    password.dispose();
  }

  Future<void> _myContributions() async {
    try {
      final results = await Future.wait([api.roadAssets(), api.placeContributions()]);
      final items = <Map<String,dynamic>>[];
      for (final item in results[0]) {
        final pos = item['pos'] as Map? ?? const {};
        items.add({'id':item['id'].toString(),'kind':'asset','name':switch ((item['kind'] as num?)?.toInt() ?? 0) {0=>'كاميرا مراقبة',1=>'رادار سرعة',2=>'إشارة مرورية',_=>'مساهمة طريق'},'lat':pos['lat'],'lng':pos['lng'],'canDelete':item['canDelete']==true});
      }
      for (final item in results[1]) {
        final pos = item['pos'] as Map? ?? const {};
        items.add({'id':item['id'].toString(),'kind':'place','name':item['name']?.toString() ?? 'مكان','lat':pos['lat'],'lng':pos['lng'],'canDelete':item['canDelete']==true});
      }
      if (!mounted) return;
      await showModalBottomSheet<void>(context:context,isScrollControlled:true,builder:(ctx)=>StatefulBuilder(builder:(ctx,setSheet)=>SafeArea(child:SizedBox(height:MediaQuery.of(ctx).size.height*.65,child:Column(children:[
        const Padding(padding:EdgeInsets.all(16),child:Text('مساهماتي على الخريطة',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold))),
        Expanded(child:items.isEmpty?const Center(child:Text('لا توجد مساهمات.')):ListView.builder(itemCount:items.length,itemBuilder:(ctx,i){final item=items[i];return ListTile(leading:Icon(item['kind']=='asset'?Icons.traffic:Icons.place_outlined),title:Text(item['name'].toString()),subtitle:Text('${item['lat']}, ${item['lng']}'),trailing:Row(mainAxisSize:MainAxisSize.min,children:[IconButton(tooltip:'عرض على الخريطة',icon:const Icon(Icons.near_me),onPressed:(){Navigator.pop(ctx);final lat=(item['lat'] as num?)?.toDouble();final lng=(item['lng'] as num?)?.toDouble();if(lat!=null&&lng!=null)map?.flyTo(CameraOptions(center:Point(coordinates:Position(lng,lat)),zoom:17),MapAnimationOptions(duration:650));}),if(item['canDelete']==true)IconButton(tooltip:'حذف مساهمتي',icon:const Icon(Icons.delete_outline),onPressed:()async{try{if(item['kind']=='asset'){await api.deleteRoadAsset(item['id'].toString());}else{await api.deletePlaceContribution(item['id'].toString());}items.removeAt(i);setSheet((){});await _refreshSharedMapData();_message('تم حذف المساهمة.');}catch(e){_message(e.toString().replaceFirst('Exception: ',''));}})]));})),
      ])))));
    } catch (e) { _message('تعذر تحميل المساهمات: ${e.toString().replaceFirst('Exception: ', '')}'); }
  }

  Future<void> _editProfile() async {
    if (user == null) { await _account(); return; }
    final name = TextEditingController(text: user?['name']?.toString() ?? '');
    final email = TextEditingController(text: user?['email']?.toString() ?? '');
    final currentPassword = TextEditingController();
    final newPassword = TextEditingController();
    bool saving = false;
    await showDialog<void>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setDialog) => AlertDialog(
      title: const Text('تعديل الملف الشخصي'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'الاسم')),
        TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'البريد الإلكتروني')),
        TextField(controller: currentPassword, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور الحالية (عند تغيير البريد/كلمة المرور)')),
        TextField(controller: newPassword, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة مرور جديدة (اختياري)')),
      ])),
      actions: [TextButton(onPressed: saving ? null : () => Navigator.pop(ctx), child: const Text('إلغاء')), FilledButton(onPressed: saving ? null : () async {
        if (name.text.trim().isEmpty || !RegExp(r'^\S+@\S+\.\S+$').hasMatch(email.text.trim())) { _message('أدخل اسمًا وبريدًا إلكترونيًا صحيحين.'); return; }
        if (newPassword.text.isNotEmpty && newPassword.text.length < 6) { _message('كلمة المرور الجديدة يجب ألا تقل عن 6 أحرف.'); return; }
        setDialog(() => saving = true);
        try { final data = await api.updateProfile(name: name.text, email: email.text, currentPassword: currentPassword.text, newPassword: newPassword.text); if (mounted) setState(() => user = data['user'] as Map<String,dynamic>?); if (ctx.mounted) Navigator.pop(ctx); _message('تم تحديث الملف الشخصي.'); }
        catch (e) { _message(e.toString().replaceFirst('Exception: ', '')); }
        finally { if (ctx.mounted) setDialog(() => saving = false); }
      }, child: saving ? const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)) : const Text('حفظ'))],
    )));
    name.dispose(); email.dispose(); currentPassword.dispose(); newPassword.dispose();
  }

  Future<void> _contributePlace() async {
    if (user == null) {
      _message('سجّل الدخول أولاً لإضافة مكان.');
      await _account();
      return;
    }
    final position = await _ensurePosition();
    if (position == null) return;
    final name = TextEditingController();
    int kind = 0;
    bool roadAsset = false;
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheet) => Padding(
          padding: EdgeInsets.fromLTRB(18, 18, 18, MediaQuery.of(ctx).viewInsets.bottom + 18),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('إضافة مكان إلى الخريطة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SwitchListTile(value: roadAsset, contentPadding: EdgeInsets.zero, title: const Text('مساهمة إرشادية للطريق'), subtitle: const Text('كاميرا أو رادار أو إشارة مرورية'), onChanged: (value) => setSheet(() { roadAsset = value; kind = 0; })),
            if (!roadAsset) TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم المكان')),
            DropdownButtonFormField<int>(
              key: ValueKey('contribution-kind-$roadAsset'),
              value: kind,
              decoration: InputDecoration(labelText: roadAsset ? 'نوع المساهمة الإرشادية' : 'نوع المكان'),
              items: roadAsset ? const [
                DropdownMenuItem(value: 0, child: Text('كاميرا مراقبة')),
                DropdownMenuItem(value: 1, child: Text('رادار سرعة')),
                DropdownMenuItem(value: 2, child: Text('إشارة مرورية')),
              ] : const [
                DropdownMenuItem(value: 0, child: Text('مكان عام')),
                DropdownMenuItem(value: 1, child: Text('مطعم أو متجر')),
                DropdownMenuItem(value: 2, child: Text('خدمة أو محطة')),
                DropdownMenuItem(value: 3, child: Text('مرفق عام')),
                DropdownMenuItem(value: 4, child: Text('مكان مهم')),
                DropdownMenuItem(value: 5, child: Text('أخرى')),
              ],
              onChanged: (value) => setSheet(() => kind = value ?? 0),
            ),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: () async {
                try {
                  if (roadAsset) { await api.createRoadAsset(kind: kind, lat: position.latitude, lng: position.longitude); } else { if (name.text.trim().isEmpty) { _message('اكتب اسم المكان أولاً.'); return; } await api.contributePlace(name: name.text, kind: kind, lat: position.latitude, lng: position.longitude); }
                  await _refreshSharedMapData(); await _restoreUser();
                  if (ctx.mounted) Navigator.pop(ctx);
                  _message('تم إرسال المساهمة.');
                } catch (e) {
                  _message(e.toString().replaceFirst('Exception: ', ''));
                }
              },
              child: const Text('إرسال المساهمة'),
            ),
          ]),
        ),
      ),
    );
    name.dispose();
  }

  Future<geo.Position?> _ensurePosition() async {
    try {
      current ??= await location.currentPosition();
      return current;
    } catch (e) {
      _message(e.toString().replaceFirst('Exception: ', ''));
      return null;
    }
  }

  Future<void> _shareLocation() async {
    if (user == null) { _message('سجّل الدخول أولاً لمشاركة الموقع.'); await _account(); return; }
    final position = await _ensurePosition();
    if (position == null) return;
    try {
      if (liveToken != null && liveOwnerKey != null) {
        await api.stopLiveShare(token: liveToken!, ownerKey: liveOwnerKey!);
        liveToken = null; liveOwnerKey = null;
        liveTimer?.cancel(); liveTimer = null;
        await widget.prefs.remove('wyn_live_token'); await widget.prefs.remove('wyn_live_owner');
        if (!navigating) { await positionSubscription?.cancel(); positionSubscription = null; }
        _message('تم إيقاف مشاركة الموقع.');
        return;
      }
      final result = await api.createLiveShare(lat: position.latitude, lng: position.longitude, heading: position.heading.isFinite ? position.heading : null, speed: position.speed.isFinite ? position.speed : null);
      liveToken = result['token']?.toString(); liveOwnerKey = result['owner_key']?.toString();
      if (liveToken == null || liveOwnerKey == null) throw Exception('لم يُرجع الخادم رمز مشاركة صالحًا.');
      await widget.prefs.setString('wyn_live_token', liveToken!); await widget.prefs.setString('wyn_live_owner', liveOwnerKey!);
      await _ensurePositionStream();
      liveTimer?.cancel(); liveTimer = Timer.periodic(const Duration(seconds: 11), (_) async {
        final p = current;
        final t = liveToken; final k = liveOwnerKey;
        if (p == null || t == null || k == null) return;
        try { await api.updateLiveShare(token: t, ownerKey: k, lat: p.latitude, lng: p.longitude, heading: p.heading.isFinite ? p.heading : null, speed: p.speed.isFinite ? math.max(0, p.speed).toDouble() : null); } catch (_) {}
      });
      final base = WynApi.baseUrl.replaceAll(RegExp(r'/+$'), '').replaceFirst(RegExp(r'/api$'), '');
      final url = '$base/?track=${Uri.encodeQueryComponent(liveToken!)}';
      await Share.share('تابع موقعي ومساري مباشرة عبر WYN Nav Street:\n$url');
      _message('مشاركة الموقع فعّالة؛ يُحدّث التطبيق موقعك كل 11 ثانية أثناء عمله.');
    } catch (e) { _message(e.toString().replaceFirst('Exception: ', '')); }
  }

  @override
  void dispose() {
    clockTimer?.cancel(); trafficTimer?.cancel(); liveTimer?.cancel(); mapDataTimer?.cancel();
    positionSubscription?.cancel();
    tts.stop();
    super.dispose();
  }

  String _reportName(dynamic t)=>switch(t){0=>'بلاغ آخر',1=>'حادث مروري',2=>'رادار',3=>'نقطة تفتيش',4=>'ازدحام',5=>'خطر على الطريق',6=>'إغلاق طريق',7=>'كاميرا',8=>'إشارة مرورية',_=>'بلاغ مروري'};
  void _message(String m){if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(m)));}
  @override
  Widget build(BuildContext context) {
    final hasToken = token.isNotEmpty;
    final size = MediaQuery.sizeOf(context);
    final landscape = size.width > size.height;
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(
              child: hasToken
                  ? MapWidget(
                      key: const ValueKey('wyn-map'),
                      styleUri: MapboxStyles.STANDARD,
                      cameraOptions: CameraOptions(
                        center: Point(coordinates: Position(44.3661, 33.3152)),
                        zoom: 11.5,
                        pitch: 35,
                      ),
                      onMapCreated: onMapCreated,
                    )
                  : Container(
                      color: Theme.of(context).colorScheme.surfaceContainerHighest,
                      child: const Center(child: Text('يلزم إعداد مفتاح Mapbox لتشغيل الخريطة')),
                    ),
            ),
            Positioned(
              top: 12,
              left: 12,
              right: 12,
              child: Row(
                children: [
                  Expanded(
                    child: Material(
                      elevation: 4,
                      borderRadius: BorderRadius.circular(18),
                      color: Theme.of(context).colorScheme.surface,
                      child: InkWell(
                        onTap: _searchDestination,
                        borderRadius: BorderRadius.circular(18),
                        child: const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 14, vertical: 15),
                          child: Row(children: [
                            Icon(Icons.search),
                            SizedBox(width: 10),
                            Expanded(child: Text('ابحث عن مكان أو عنوان')),
                            Icon(Icons.mic_none),
                          ]),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  _circle(user == null ? Icons.account_circle_outlined : Icons.account_circle, _account),
                ],
              ),
            ),
            Positioned(
              right: 12,
              bottom: landscape ? 18 : 118,
              child: Column(children: [
                _circle(traffic ? Icons.traffic : Icons.traffic_outlined, _toggleTraffic, active: traffic),
                const SizedBox(height: 9),
                _circle(is3d ? Icons.view_in_ar : Icons.layers_outlined, () => _set3d(!is3d)),
                const SizedBox(height: 9),
                _circle(busy ? Icons.hourglass_top : Icons.my_location, _locate),
              ]),
            ),
            Positioned(
              left: 12,
              right: landscape ? null : 12,
              width: landscape ? 320 : null,
              top: landscape ? 76 : null,
              bottom: 12,
              child: Container(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface.withOpacity(.97),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 18)],
                ),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Row(children: [
                    Icon(Icons.navigation, color: Theme.of(context).colorScheme.primary),
                    const SizedBox(width: 8),
                    Expanded(child: Text(status, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600))),
                    TextButton(onPressed: _searchDestination, child: const Text('الوجهة')),
                  ]),
                  if (navigating) ...[
                    Row(children: [
                      Expanded(child: Text(_maneuverStatus(), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600))),
                      Container(padding: const EdgeInsets.symmetric(horizontal:8,vertical:6),decoration:BoxDecoration(color:Theme.of(context).colorScheme.primaryContainer,borderRadius:BorderRadius.circular(10)),child:Text('${((current?.speed ?? 0) * 3.6).round()} كم/س',style:const TextStyle(fontWeight:FontWeight.bold,fontSize:11))),
                      IconButton(tooltip: voiceEnabled ? 'إيقاف التوجيه الصوتي' : 'تشغيل التوجيه الصوتي', onPressed: () => setState(() => voiceEnabled = !voiceEnabled), icon: Icon(voiceEnabled ? Icons.volume_up : Icons.volume_off)),
                      IconButton(tooltip: 'إنهاء الملاحة', onPressed: _stopNavigation, icon: const Icon(Icons.stop_circle_outlined, color: Colors.red)),
                    ]),
                  ] else if (alternatives.isNotEmpty) ...[
                    Row(children: [Expanded(child: Text('${destination?.name ?? 'الوجهة'} · ${alternatives[selectedRoute].distanceLabel} · ${alternatives[selectedRoute].durationLabel}', maxLines: 1, overflow: TextOverflow.ellipsis)), IconButton(tooltip:'حفظ الوجهة', onPressed:_saveDestination, icon:const Icon(Icons.bookmark_add_outlined)), TextButton.icon(onPressed: _showRouteSheet, icon: const Icon(Icons.alt_route), label: const Text('تغيير'))]),
                    SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _startNavigation, icon: const Icon(Icons.navigation), label: const Text('ابدأ الملاحة'))),
                  ],
                  const Divider(height: 10),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                    _bottom(Icons.map_outlined, 'الخريطة', () => setState(() => status = 'جاهز للملاحة')),
                    _bottom(Icons.route, 'المسارات', _searchDestination),
                    _bottom(Icons.campaign_outlined, 'البلاغات', _reports),
                    _bottom(Icons.stars_outlined, 'النقاط', _account),
                    _bottom(Icons.add_location_alt_outlined, 'إضافة مكان', _contributePlace),
                  ]),
                ]),
              ),
            ),
            if (busy) const Positioned(top: 76, left: 0, right: 0, child: LinearProgressIndicator(minHeight: 2)),
          ],
        ),
      ),
    );
  }
  Widget _circle(IconData icon,VoidCallback fn,{bool active=false})=>Material(color:active?Theme.of(context).colorScheme.primary:Theme.of(context).colorScheme.surface,elevation:4,shape:const CircleBorder(),child:IconButton(onPressed:fn,icon:Icon(icon,color:active?Colors.white:null)));
  Widget _bottom(IconData icon,String label,VoidCallback fn)=>InkWell(onTap:fn,borderRadius:BorderRadius.circular(12),child:Padding(padding:const EdgeInsets.symmetric(horizontal:6,vertical:3),child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(icon,size:22),const SizedBox(height:3),Text(label,style:const TextStyle(fontSize:11))])));
}

class PlaceSearchSheet extends StatefulWidget {
  const PlaceSearchSheet({super.key, required this.service, required this.current, required this.savedPlaces, required this.onSelect});
  final MapboxService service;
  final geo.Position? current;
  final List<PlaceResult> savedPlaces;
  final ValueChanged<PlaceResult> onSelect;
  @override State<PlaceSearchSheet> createState() => _PlaceSearchSheetState();
}
class _PlaceSearchSheetState extends State<PlaceSearchSheet> {
  final controller = TextEditingController();
  List<PlaceResult> results = [];
  bool loading = false;
  String? error;
  @override void dispose() { controller.dispose(); super.dispose(); }
  Future<void> search() async {
    if (controller.text.trim().isEmpty || loading) return;
    setState(() { loading = true; error = null; });
    try {
      final p = widget.current;
      final found = await widget.service.search(controller.text.trim(), lon: p?.longitude, lat: p?.latitude);
      if (!mounted) return;
      setState(() { results = found; if (found.isEmpty) error = 'لم يتم العثور على نتائج.'; });
    } catch (e) {
      if (mounted) setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally { if (mounted) setState(() => loading = false); }
  }
  @override Widget build(BuildContext context) => Padding(
    padding: EdgeInsets.fromLTRB(18, 18, 18, MediaQuery.of(context).viewInsets.bottom + 18),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Row(children: [const Expanded(child: Text('إلى أين تريد الذهاب؟', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold))), IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close))]),
      TextField(controller: controller, autofocus: true, onSubmitted: (_) => search(), decoration: InputDecoration(hintText: 'اسم المكان أو العنوان', prefixIcon: const Icon(Icons.search), suffixIcon: IconButton(icon: const Icon(Icons.arrow_forward), onPressed: search), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))),
      if (widget.savedPlaces.isNotEmpty) ...[const Align(alignment:Alignment.centerRight, child:Padding(padding:EdgeInsets.only(top:12,bottom:4),child:Text('الوجهات المحفوظة',style:TextStyle(fontWeight:FontWeight.bold)))), ...widget.savedPlaces.take(8).map((p)=>ListTile(dense:true,leading:const Icon(Icons.bookmark_outline),title:Text(p.name,maxLines:1,overflow:TextOverflow.ellipsis),onTap:()=>widget.onSelect(p)))],
      if (loading) const Padding(padding: const EdgeInsets.all(14), child: CircularProgressIndicator()),
      if (error != null) Padding(padding: const EdgeInsets.all(8), child: Text(error!, style: const TextStyle(color: Colors.red))),
      Flexible(child: ListView(shrinkWrap: true, children: results.map((p) => ListTile(leading: const Icon(Icons.place_outlined), title: Text(p.name), onTap: () => widget.onSelect(p))).toList())),
    ]),
  );
}
